# visudo

> Safely edit the sudoers file.

- Edit sudoers file:

`sudo visudo`

- Check sudoers file for errors:

`sudo visudo -c`
