# hr

> Print a horizontal rule in the terminal.

- Print a horizontal rule:

`hr`

- Print a horizontal rule with a custom string:

`hr {{string}}`

- Print a multiline horizontal rule:

`hr {{string_a}} {{string_b}} {{string_c}}`
