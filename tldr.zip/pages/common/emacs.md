# emacs

> The extensible, customizable, self-documenting, real-time display editor.
> More information: <https://www.gnu.org/software/emacs>.

- Start emacs in console mode (without X window):

`emacs -nw`

- Open a file in emacs:

`emacs {{filename}}`

- Exit emacs (save buffers and terminate):

`Ctrl + X, Ctrl + C`
