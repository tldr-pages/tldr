# subliminal

> Python-based subtitle downloader.
> More information: <https://github.com/Diaoul/subliminal>.

- Download English subtitles for a video:

`subliminal download -l {{en}} {{video.ext}}`
