# ocaml

> The OCaml repl (read-evaluate-print-loop).
> Interprets Ocaml commands.

- Read OCaml commands from the user and execute them:

`ocaml`

- Read OCaml commands from a file and execute them:

`ocaml {{path/to/file.ml}}`
