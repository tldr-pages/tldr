# yes

> Output something repeatedly.

- Repeatedly output "message":

`yes {{message}}`

- Repeatedly output "y":

`yes`
