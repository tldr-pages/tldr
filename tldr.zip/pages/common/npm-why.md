# npm-why

> Identifies why an npm package is installed.
> More information: <https://www.npmjs.com/package/npm-why>.

- Show why an npm package is installed:

`npm-why {{package-name}}`
