# home-manager

> Manage a user environment using Nix.
> More information: <https://github.com/rycee/home-manager>.

- Activate the configuration defined in `~/.config/nixpkgs/home.nix`:

`home-manager build`

- Activate the configuration and switch to it:

`home-manager switch`
