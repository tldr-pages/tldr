# guniq

> This command is an alias of GNU `uniq`.

- View documentation for the original command:

`tldr uniq`
