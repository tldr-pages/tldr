# grcp

> This command is an alias of GNU `rcp`.

- View documentation for the original command:

`tldr {{[-p|--platform]}} linux rcp`
