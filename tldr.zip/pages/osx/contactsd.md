# contactsd

> Manages the information in your contacts database.
> It provides functionality to apps using the Contacts API and performs various background maintenance tasks.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/contactsd.8.html>.

- Start the daemon:

`contactsd`
