# gb2sum

> This command is an alias of GNU `b2sum`.

- View documentation for the original command:

`tldr b2sum`
