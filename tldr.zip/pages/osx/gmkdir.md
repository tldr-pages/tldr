# gmkdir

> This command is an alias of GNU `mkdir`.

- View documentation for the original command:

`tldr mkdir`
