# gfactor

> This command is an alias of GNU `factor`.

- View documentation for the original command:

`tldr factor`
