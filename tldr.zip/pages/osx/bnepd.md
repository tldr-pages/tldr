# bnepd

> A service that handles all Bluetooth network connections.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/bnepd/>.

- Start the daemon:

`bnepd`
