# hidd

> HID library userland daemon.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/hidd.8.html>.

- Start the daemon:

`hidd`
