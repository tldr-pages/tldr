# gtest

> This command is an alias of GNU `test`.

- View documentation for the original command:

`tldr test`
