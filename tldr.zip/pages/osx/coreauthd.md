# coreauthd

> A system daemon providing the `LocalAuthentication` framework.
> It should not be invoked manually.
> See also: `coreautha`.
> More information: <https://keith.github.io/xcode-man-pages/coreauthd.8.html>.

- Start the agent:

`coreauthd`
