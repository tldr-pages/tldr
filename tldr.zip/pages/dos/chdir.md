# CHDIR

> This command is an alias of `CD`.

- View documentation for the original command:

`tldr {{[-p|--platform]}} dos cd`
