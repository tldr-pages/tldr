# write

> Write data to memory.
> More information: <https://www.oreilly.com/library/view/cisco-ios-in/0596008694/re869.html#book-content>.

- Write current configuration to memory:

`write memory`

- Delete the configuration in memory:

`write erase`

- Display help:

`write ?`
