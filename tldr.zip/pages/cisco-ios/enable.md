# enable

> Enter privileged execution mode.
> More information: <https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/security/d1/sec-d1-cr-book/sec-cr-e1.html#wp3307186499>.

- Enter privileged execution mode:

`enable`
