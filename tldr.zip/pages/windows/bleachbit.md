# bleachbit

> This command is an alias of `bleachbit_console`.

- View documentation for the original command:

`tldr bleachbit_console`
