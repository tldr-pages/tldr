# mimikatz standard

> Basic commands and mimikatz environment management.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- Display system information:

`mimikatz "standard::info"`

- Clear the mimikatz command history:

`mimikatz "standard::clearev"`

- Show command history:

`mimikatz "standard::history"`
