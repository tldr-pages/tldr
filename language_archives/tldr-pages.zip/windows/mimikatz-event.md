# mimikatz event

> Manage Windows Event Log records.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- Clear event logs:

`mimikatz "event::clear"`

- Display event log sources:

`mimikatz "event::providers"`
