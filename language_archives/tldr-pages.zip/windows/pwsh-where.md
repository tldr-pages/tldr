# pwsh where

> This command is an alias of `Where-Object`.

- View documentation for the original command:

`tldr Where-Object`
