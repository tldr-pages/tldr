# rev

> Reverse lines of text.
> More information: <https://keith.github.io/xcode-man-pages/rev.1.html>.

- Reverse each line in a file to `stdout`:

`rev {{path/to/file}}`

- Reverse each line from `stdin` to `stdout`:

`{{command}} | rev`
