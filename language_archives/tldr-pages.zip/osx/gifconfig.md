# gifconfig

> This command is an alias of GNU `ifconfig`.

- View documentation for the original command:

`tldr ifconfig`
