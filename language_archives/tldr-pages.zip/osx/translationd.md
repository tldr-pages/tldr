# translationd

> Enables Translation features.
> It should not be invoked manually.

- Start the daemon:

`translationd`
