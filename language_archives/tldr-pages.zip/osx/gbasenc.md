# gbasenc

> This command is an alias of GNU `basenc`.

- View documentation for the original command:

`tldr basenc`
