# ggroups

> This command is an alias of GNU `groups`.

- View documentation for the original command:

`tldr groups`
