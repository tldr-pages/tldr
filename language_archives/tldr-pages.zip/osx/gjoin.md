# gjoin

> This command is an alias of GNU `join`.

- View documentation for the original command:

`tldr join`
