# gnice

> This command is an alias of GNU `nice`.

- View documentation for the original command:

`tldr nice`
