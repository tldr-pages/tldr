# gpinky

> This command is an alias of GNU `pinky`.

- View documentation for the original command:

`tldr pinky`
