# guname

> This command is an alias of GNU `uname`.

- View documentation for the original command:

`tldr {{[-p|--platform]}} common uname`
